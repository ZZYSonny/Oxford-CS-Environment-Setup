package practical1

import io.threadcso._

object mycomponent {
    def input[T](ins: List[![T]], data: List[T]) =
        || (for ((ch, x) <- ins zip data)
            yield proc{ch!x})

    def getOutputs[T](ins: List[?[T]]): List[T] = ins.map(_.?)

    def output[T](ins: List[?[T]]): PROC = proc("output list") {
        println(getOutputs(ins))
    }

    def checkOutput[T](ins: List[?[T]],ans: List[T]): PROC = proc("check list"){
        println(getOutputs(ins) == ans)
    }

    def OneOneList[T](n:Int):List[Chan[T]] = List.fill(n)(OneOne[T])

    def randomIntList(n:Int):List[Int] = List.fill(4)(scala.util.Random.nextInt(100))

    def copyOnce[T](in: ?[T], out: ![T]):PROC = proc{out!(in?())}

    def copyOnceAll[T](ins: Array[?[T]], outs: Array[![T]], instart:Int,  outstart:Int, len:Int):PROC =
        || ( for(i<- 0 until len)
                yield copyOnce(ins(instart+i),outs(outstart+i)))
}
