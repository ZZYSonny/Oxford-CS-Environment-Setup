package practical1

import io.threadcso._

object main {
    //task1
    def comparator(in0: ?[Int], in1: ?[Int], out0: ![Int], out1: ![Int]): PROC = proc("comparator") {
        val x = in0 ?()
        val y = in1 ?()
        if(x<y) run(proc { out0 ! x } || proc { out1 ! y })
        else run(proc { out0 ! y } || proc { out1 ! x })
    }

    def test1 = {
        val in0, in1, out0, out1 = OneOne[Int]
        val cmp = comparator(in0, in1, out0, out1)
        val input = mycomponent.input(List(in0,in1),List(2,1))
        val output = mycomponent.output(List(out0,out1))
        cmp || input || output
    }

    //task2
    def sort4(ins: List[?[Int ]], outs: List [![ Int ]]): PROC = {
        require(ins.length == 4 && outs.length == 4)
        val out10,out11,out12,out13 = OneOne[Int]
        val out21,out22 = OneOne[Int]
        val level1 = comparator(ins(0),ins(2),out10,out12) || comparator(ins(1),ins(3),out11,out13)
        val level2 = comparator(out10,out11,outs(0),out21) || comparator(out12,out13,out22,outs(3))
        val level3 = comparator(out21,out22,outs(1),outs(2))
        level1 || level2 || level3
    }

    def test2 = {
        val indata = List(4,3,2,1)
        val n = indata.length
        val ins = mycomponent.OneOneList[Int](n)
        val outs = mycomponent.OneOneList[Int](n)
        val work = sort4(ins,outs)
        val input = mycomponent.input(ins,indata)
        val output = mycomponent.checkOutput(outs,indata.sorted)
        work || input || output
    }

    //task3
    def insert3(ins: List[?[Int ]], in: ?[Int], outs: List [![ Int ]]): PROC = {
        val n = ins.length; require(n >= 1 && outs.length == n+1)
        if(n==1) {
            comparator(ins.head,in,outs(0),outs(1))
        } else {
            val tmp = OneOne[Int]
            val l1 = comparator(in, ins.head, outs.head, tmp)
            val l2 = insert3(ins.tail, tmp, outs.tail)
            l1 || l2
        }
    }

    def test3() ={
        val inint = 4
        val inlist = List(1,2,3)
        val n = inlist.length
        val in = OneOne[Int]
        val ins = mycomponent.OneOneList[Int](n)
        val outs = mycomponent.OneOneList[Int](n+1)
        val input = mycomponent.input(ins,inlist) || component.const(inint)(in)
        val output = mycomponent.checkOutput(outs,(inint::inlist).sorted)
        val work = insert3(ins,in,outs)
        work || input || output
    }

    //task 4
    //like qsort
    def insert4(ins: List[?[Int ]], in: ?[Int], outs: List [![ Int ]]): PROC = proc{
        val n = ins.length; require(n >= 1 && outs.length == n+1)
        val invalue = in?()
        val arrayins = ins.toArray
        val arrayouts = outs.toArray

        def work(l:Int,r:Int):PROC = {
            if(r-l==1){
                val lvalue = arrayins(l) ? ()
                component.const(invalue min lvalue)(arrayouts(l)) || component.const(invalue max lvalue)(arrayouts(l+1))
            } else proc{
                //[l,mid) mid (mid,r)
                val mid = (l + r) / 2
                val midvalue = arrayins(mid) ? ()
                if (invalue < midvalue) {
                    //[l,mid) invalue mid   (mid,r)
                    //   [l,mid+1)   mid+1  [mid+2,r+1)
                    val leftpart = work(l, mid)
                    val midpart = component.const(midvalue)(outs(mid + 1))
                    val rightpart = mycomponent.copyOnceAll(arrayins, arrayouts, mid + 1, mid + 2, r - mid - 1)
                    run(leftpart || midpart || rightpart)
                } else {
                    //[l,mid) mid   (mid,r) invalue
                    //[l,mid) mid   [mid+1,r+1)
                    val leftpart = mycomponent.copyOnceAll(arrayins, arrayouts, l, l, mid - l)
                    val midpart = component.const(midvalue)(outs(mid))
                    val rightpart = work(mid + 1, r)
                    run(leftpart || midpart || rightpart)
                }
            }
        }

        run(work(0,n))
    }

    def test4() ={
        val inint = 4
        val inlist = List(1,2,3)
        val n = inlist.length
        val in = OneOne[Int]
        val ins = mycomponent.OneOneList[Int](n)
        val outs = mycomponent.OneOneList[Int](n+1)
        val input = mycomponent.input(ins,inlist) || component.const(inint)(in)
        val output = mycomponent.checkOutput(outs,(inint::inlist).sorted)
        val work = insert4(ins,in,outs)
        work || input || output
    }


    //task5
    def insertionSort(ins: List[?[Int ]], outs: List [![ Int ]]): PROC = {
        val n = ins.length; require(n >= 2 && outs.length == n)
        if(n==2) {
            comparator(ins(0),ins(1),outs(0),outs(1))
        } else {
            val tmp = mycomponent.OneOneList[Int](n - 1)
            val l1 = insertionSort(ins.tail, tmp)
            val l2 = insert3(tmp, ins.head, outs)
            l1 || l2
        }
    }

    def test5 = {
        val indata = List(8,7,6,5,4,3,2,1)
        val n = indata.length
        val ins = mycomponent.OneOneList[Int](n)
        val outs = mycomponent.OneOneList[Int](n)
        val work = insertionSort(ins,outs)
        val input = mycomponent.input(ins,indata)
        val output = mycomponent.checkOutput(outs,indata.sorted)
        work || input || output
    }


    def main(args: Array[String]): Unit = {
        run(test5)
    }
}
