// Program to show the dangers of undisciplined shared variables

import io.threadcso._

object Race {
    var x = 0

    // Process to increment x 1000 times
    def p = proc {
        for (i <- 0 until 1000)
            x = x + 1
    }

    // Process to decrement x 1000 times
    def q = proc {
        for (i <- 0 until 1000)
            x = x - 1
    }

    // Parallel composition
    def system = p || q

    def main(args: Array[String]): Unit = {
        run(system)
        println(x)
        exit()
    }
}