object test {
    object test{
        def ?(): Unit = {
            println("??")
        }

        def !(): Unit = {
            println("!!")
        }

        def lol():Unit  = {
            print("LOL")
        }
    }

    def main(args: Array[String]): Unit = {
    }
}
